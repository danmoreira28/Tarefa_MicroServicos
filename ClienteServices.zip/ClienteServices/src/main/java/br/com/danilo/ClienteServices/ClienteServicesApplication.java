package br.com.danilo.ClienteServices;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ClienteServicesApplication {

	public static void main(String[] args) {
		SpringApplication.run(ClienteServicesApplication.class, args);
	}

}
